package com.rohith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAppnRepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAppnRepoApplication.class, args);
	}

}
