package com.rohith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebApplication1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
